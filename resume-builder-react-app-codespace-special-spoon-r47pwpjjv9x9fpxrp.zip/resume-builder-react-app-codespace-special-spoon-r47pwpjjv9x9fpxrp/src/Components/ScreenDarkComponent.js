import React from "react";
import "../Styles/ScreenDarkComponent.css";

const ScreenDarkComponent = (props) => {
  return <div className="black-screen"></div>;
};

export default ScreenDarkComponent;